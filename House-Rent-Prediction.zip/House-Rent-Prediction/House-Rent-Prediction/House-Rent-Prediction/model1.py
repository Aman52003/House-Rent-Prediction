import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import pickle

#df = pd.read_csv(r"C:\Users\Admin\OneDrive - JK LAKSHMIPAT UNIVERSITY\Pictures\VIDEO\House-Rent-Prediction-Website-main\House-Rent-Prediction-Website-main\House_Rent_Dataset.csv")
df = pd.read_csv(r"E:\ML\House-Rent-Prediction-Website-main (2)\House-Rent-Prediction-Website-main\House-Rent-Prediction-Website-main\House_Rent_Dataset.csv")



df['City'] = df['City'].replace(["Mumbai","Bangalore","Hyderabad","Delhi","Chennai","Kolkata"],[5,4,3,2,1,0])
df['Furnishing Status'] = df['Furnishing Status'].replace(["Furnished","Semi-Furnished","Unfurnished"],[2,1,0])

target = df.pop("Rent")

from sklearn.model_selection import train_test_split
x_train, x_test, y_train , y_test = train_test_split(df, target, test_size=0.2)

from sklearn.ensemble import RandomForestRegressor
lin_reg = RandomForestRegressor()
lin_reg.fit(x_train,y_train)

# from sklearn.linear_model import  LinearRegression
# lin_reg = LinearRegression()
# lin_reg.fit(x_train,y_train)



print(lin_reg.score(x_train,y_train))
pickle.dump(lin_reg, open('model1.pkl','wb'))

