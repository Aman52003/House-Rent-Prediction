# import pandas as pd
# df = pd.read_csv("House-Rent-Prediction-Website-main\House_Rent_Dataset.csv")
# print(df['Area Locality'])
# arr = df['Area Locality']
# for i in range (len(arr)):
#     print("<option value='",arr[i],"'>",arr[i],"</option>")
